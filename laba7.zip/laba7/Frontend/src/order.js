/**
 * Created by chaika on 25.01.16.
 */


$(function(){
    //This code will execute when the page is ready
	var PizzaCart = require('./pizza_order/PizzaCart');
	var valid = require('./pizza_order/Valid');
	var API = require('./API');
	var google = require('./pizza_order/google');

	PizzaCart.initialiseCart();
	valid.init();
	google.initialize();
	$('#order_btn').click(function() {
		if (valid.check()) {

			$('#one').hide();
			order();



			
			// API.createOrder(ord, function() {console.log('Order completed ')});
			$('#two').show();
		}
	});

	function order(ord)
{
	var ord = {
		name: $('#name').val().trim(),
		phone: $('#phone').val().trim(),
		adres: $('#adres').val().trim(),
		cart: PizzaCart.getPizzaInCart()
	};
	API.createOrder(ord, function(fail, rse) {
		var result = JSON.parse(rse);
	LiqPayCheckout.init({
			data: result.data,
			signature: result.signature,
			embedTo: "#privat",
			mode: "embed"
		}).on("liqpay.callback",function(paymentResult) {
				if (paymentResult.status === "sandbox")
				PizzaCart.del();
				
});
	});
}


});