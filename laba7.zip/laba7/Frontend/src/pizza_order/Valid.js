var gogle = require('./google');

function init() {
	$('#name').focusout(function () {
		var fail = name();
		if (fail) {
			$('#name_text').addClass('fail');
			$('#name').addClass('fail_inp');
			$('#name_fail').removeClass('hidden');
		} else {
			$('#name_text').removeClass('fail');
			$('#name').removeClass('fail_inp');
			$('#name_fail').addClass('hidden');
		}
	});
	$('#phone').focusout(function () {
		var fail = phone();
		if (fail) {
			$('#phone_text').addClass('fail');
			$('#phone').addClass('fail_inp');
			$('#phone_fail').removeClass('hidden');
		} else {
			$('#phone_text').removeClass('fail');
			$('#phone').removeClass('fail_inp');
			$('#phone_fail').addClass('hidden');
		}
	});
	$('#adres').focusout(function() {
		if ($('#adres').val().trim().length<8) fail();
		gogle.check($('#adres').val().trim());
	});
}

function fail() {
	$('#adres_text').addClass('fail');
			$('#adres').addClass('fail_inp');
			$('#adres_fail').removeClass('hidden');

	$('#info_time').text('невідомий');
	$('#info_adres').text('невідома');
}

function corect(time, adres) {
	$('#adres_text').removeClass('fail');
			$('#adres').removeClass('fail_inp');
			$('#adres_fail').addClass('hidden');

			$('#adres').val(adres);
			$('#info_time').text(time);
			$('#info_adres').text(adres);
}

function check() {
	return !name() && !phone() && !adres();
}

function name() {
	var name= $('#name').val().trim();
	if (name.length <8) return true;
	for (var i= 0;i<name.length; i++) {
		if (name.charAt(i).toUpperCase()===name.charAt(i).toLowerCase()&&name.charAt(i)!==' ') {
		return true;
	}
	}
	return false;
}

function phone() {
	var phone = $('#phone').val().trim();
	for (var i =0;i< phone.length; i++) {
		if ((phone.charAt(i)<'0'||phone.charAt(i)> '9')&&phone.charAt(i)!=='+') {
			return true;
	}
	}

	if (phone.length=== 10) {
		if (phone.charAt(0)!=='0') {
			return true;}
		return false;
	}

	if (phone.length===13) {
		if (phone.substring(0,4) !== '+380') {
		return true;
	}
	return false;
	}

return true;
}

function adres(){
	return $('#adres').hasClass("fail");
}

exports.init = init;
exports.check = check;
exports.fail = fail;
exports.corect = corect;
