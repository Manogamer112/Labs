var map;
var marker;
var drawer;

var Valid = require('./Valid')

function reset(){
if(marker) 
marker.setMap(null);
if(drawer) 
drawer.setMap(null);}

function initialize() {
	//Тут починаємо працювати з картою
	var mapProp = {
		center: new google.maps.LatLng(50.464379, 30.519131),
		zoom: 11,
	};
	var html_element = document.getElementById("google");
	map = new google.maps.Map(html_element, mapProp);
	//Карта створена і показана

	var point = new google.maps.LatLng(50.464379, 30.519131);
	var marker = new google.maps.Marker({
		position: point,
		//map	- це змінна карти створена за допомогою new	google.maps.Map(...)
		map: map,
		icon: "assets/images/map-icon.png",
	});
	initializeKlik();
}

function initializeKlik() {
	google.maps.event.addListener(map, "click", function (klik) {
		reset();
		geocodeLatLng(klik.latLng, function (fail, adress) {
			if (fail) {
				Valid.fail();
			} else {
				calculateRoute(new google.maps.LatLng(50.464379, 30.519131), klik.latLng, function (err, data) {
					if (err) Valid.fail();
					else {
						marker = new google.maps.Marker({
							position: klik.latLng,
							map: map,
							icon: "assets/images/home-icon.png",
						});
						draw(data.line);
						Valid.corect(data.time, adress);
					}
				});
			}
		});
	});
}

function draw(line){
drawer = new google.maps.DirectionsRenderer();
drawer.setMap(map);
			drawer.setOptions({ 
	suppressMarkers: true 
	});
drawer.setDirections(line);}

function geocodeLatLng(latlng, callback) {
	//Модуль за роботу з адресою
	var geocoder = new google.maps.Geocoder();
	geocoder.geocode({ location: latlng }, function (results, status) {
		if (status === google.maps.GeocoderStatus.OK && results[1]) {
			var adress = results[1].formatted_address;
			callback(null, adress);
		} else {
			callback(new Error("Can't	find	adress"));
		}
	});
}

function geocodeAddress(adres, callback) {
	var geocoder = new google.maps.Geocoder();
	geocoder.geocode({ address: adres }, function (results, status) {
		if (status === google.maps.GeocoderStatus.OK && results[0]) {
			var coordinates = results[0].geometry.location;
			callback(null, coordinates);
		} else {
			callback(new Error("Can	not	find	the	adress"));
		}
	});
}

function check(adres) {
	reset();
	geocodeAddress(adres, function(fail, cord) {
	if(!fail){
		calculateRoute(new google.maps.LatLng(50.464379, 30.519131),cord,function(fail, data) {
			if (fail)
				Valid.fail();
				else {
					marker = new google.maps.Marker({
						position:cord,
							map:map,
							icon:"assets/images/home-icon.png"
					});
					draw(data.line);
		Valid.corect(data.time, adres);
			}
		});
		}
				else Valid.fail();
	});
}

function calculateRoute(A_latlng, B_latlng, callback) {
	var directionService = new google.maps.DirectionsService();
	directionService.route(
		{
			origin: A_latlng,
			destination: B_latlng,
			travelMode: google.maps.TravelMode["DRIVING"],
		},
		function (response, status) {
			if (status == google.maps.DirectionsStatus.OK) {
				var leg = response.routes[0].legs[0];
				callback(null, {
					line: response,
					time: leg.duration.text,
				});
			} else {
			callback(new Error("Can'	not	find	direction"));
			}
		}
	);
}

exports.initialize = initialize;
exports.check = check;
