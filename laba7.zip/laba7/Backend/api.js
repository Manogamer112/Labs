/**
 * Created by chaika on 09.02.16.
 */
var Pizza_List = require('./data/Pizza_List');
var crypto = require('crypto');

exports.getPizzaList = function(req, res) {
    res.send(Pizza_List);
};

exports.createOrder = function(req, res) {
    var order_info = req.body;



var desc ='Замовлення піци: '+order_info.name+'\nАдреса доставки: '+order_info.adres + '\nТелефон: '+order_info.phone+'\nЗамовлення:\n';
var cena=0;
	for (var i=0; i<order_info.cart.length;i++) {
		cena+= order_info.cart[i].pizza[order_info.cart[i].size].price * order_info.cart[i].quantity;
		desc+=('- '+order_info.cart[i].quantity+'шт. ['+(order_info.cart[i].size==='big_size'?'Велика':'Мала')+'] ' +order_info.cart[i].pizza.title +';\n');
}
	desc+='\n'+'Разом: '+cena+'грн.';
	var order=
	{
        version:3,
        public_key:'sandbox_i66131886491',
        action: 'pay',
        amount: cena,
        currency: 'UAH',
        description: desc,
        order_id: Math.random(),
        sandbox: 1};
	
function sha1(string) {
    var sha1 = crypto.createHash('sha1');
    sha1.update(string);
    return sha1.digest('base64');
}

	var order_base64=new Buffer(JSON.stringify(order)).toString('base64');

    var result=JSON.stringify({
    data:order_base64,
    signature:sha1('sandbox_LfIkYwjIWg5WLOUoYMTpuqp95mqyQzpyMUih983x'+order_base64 +'sandbox_LfIkYwjIWg5WLOUoYMTpuqp95mqyQzpyMUih983x')
	});



    res.send(result);
};